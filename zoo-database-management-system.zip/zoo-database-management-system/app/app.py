#!/usr/bin/python3
# Copyright (c) BDist Development Team
# Distributed under the terms of the Modified BSD License.
import os
import logging
from logging.config import dictConfig
from decimal import Decimal

import psycopg
from flask import Flask, jsonify, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from psycopg.rows import namedtuple_row
from psycopg_pool import ConnectionPool

dictConfig(
    {
        "version": 1,
        "formatters": {
            "default": {
                "format": "[%(asctime)s] %(levelname)s in %(module)s:%(lineno)s - %(funcName)20s(): %(message)s",
            }
        },
        "handlers": {
            "wsgi": {
                "class": "logging.StreamHandler",
                "stream": "ext://flask.logging.wsgi_errors_stream",
                "formatter": "default",
            }
        },
        "root": {"level": "INFO", "handlers": ["wsgi"]},
    }
)

RATELIMIT_STORAGE_URI = os.environ.get("RATELIMIT_STORAGE_URI", "memory://")

app = Flask(__name__)

def decimal_to_float(value):
    if isinstance(value, Decimal):
        return float(value)
    return value


def is_number(value):
    try:
        float(value)
        return True
    except Exception:
        return False
        
app.config.from_prefixed_env()
log = app.logger
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["200 per day", "50 per hour"],
    storage_uri=RATELIMIT_STORAGE_URI,
)

# Use the DATABASE_URL environment variable if it exists, otherwise use the default.
# Use the format postgres://username:password@hostname/database_name to connect to the database.
DATABASE_URL = os.environ.get("DATABASE_URL", "postgres://app:app@postgres/app")

pool = ConnectionPool(
    conninfo=DATABASE_URL,
    kwargs={
        "autocommit": True,  # If True don’t start transactions automatically.
        "row_factory": namedtuple_row,
    },
    min_size=4,
    max_size=10,
    open=True,
    # check=ConnectionPool.check_connection,
    name="postgres_pool",
    timeout=5,
)


def is_decimal(s):
    """Returns True if string is a parseable float number."""
    try:
        float(s)
        return True
    except ValueError:
        return False


@app.route("/", methods=("GET",))
def index():
    return jsonify({"message": "Zoo API is running"}), 200

@app.route("/ping", methods=("GET",))
@limiter.exempt
def ping():
    log.debug("ping!")
    return jsonify({"message": "pong!", "status": "success"})

@app.route("/zona/<int:zona>/", methods=("GET",))
def zona_index(zona):
    """
    Lista todos os recintos da zona indicada.
    Para cada recinto, mostra as espécies nele contidas e o número de animais
    dessa espécie nesse recinto.
    """

    with pool.connection() as conn:
        with conn.cursor() as cur:

            zona_row = cur.execute(
                """
                SELECT id_zona, categoria, continente, preco
                FROM zona
                WHERE id_zona = %(zona)s;
                """,
                {"zona": zona},
            ).fetchone()

            if zona_row is None:
                return jsonify(
                    {
                        "status": "error",
                        "message": "Zona não encontrada."
                    }
                ), 404

            rows = cur.execute(
                """
                SELECT
                    r.id_recinto,
                    e.nome_cientifico,
                    e.nome_comum,
                    COUNT(a.nome) AS numero_animais
                FROM recinto r
                LEFT JOIN animal a
                    ON a.id_recinto = r.id_recinto
                LEFT JOIN especie e
                    ON e.nome_cientifico = a.nome_cientifico
                WHERE r.id_zona = %(zona)s
                GROUP BY
                    r.id_recinto,
                    e.nome_cientifico,
                    e.nome_comum
                ORDER BY
                    r.id_recinto,
                    e.nome_cientifico;
                """,
                {"zona": zona},
            ).fetchall()

    recintos = {}

    for row in rows:
        id_recinto = row.id_recinto

        if id_recinto not in recintos:
            recintos[id_recinto] = {
                "recinto": id_recinto,
                "especies": []
            }

        if row.nome_cientifico is not None:
            recintos[id_recinto]["especies"].append(
                {
                    "nome_cientifico": row.nome_cientifico,
                    "nome_comum": row.nome_comum,
                    "numero_animais": row.numero_animais
                }
            )

    return jsonify(
        {
            "zona": {
                "id_zona": zona_row.id_zona,
                "categoria": zona_row.categoria,
                "continente": zona_row.continente,
                "preco": decimal_to_float(zona_row.preco)
            },
            "recintos": list(recintos.values())
        }
    ), 200

@app.route("/recinto/<int:recinto>/voto/<int:bilhete>/", methods=("POST",))
def recinto_voto_save(recinto, bilhete):
    """
    Regista o voto de um bilhete num recinto.
    Atualiza bilhete.votou para TRUE e incrementa recinto.votos.
    """

    with pool.connection() as conn:
        with conn.cursor() as cur:
            try:
                with conn.transaction():

                    bilhete_row = cur.execute(
                        """
                        SELECT bid, votou
                        FROM bilhete
                        WHERE bid = %(bilhete)s
                        FOR UPDATE;
                        """,
                        {"bilhete": bilhete},
                    ).fetchone()

                    if bilhete_row is None:
                        return jsonify(
                            {
                                "status": "error",
                                "message": "Bilhete não encontrado."
                            }
                        ), 404

                    if bilhete_row.votou is True:
                        return jsonify(
                            {
                                "status": "error",
                                "message": "O bilhete já tinha votado."
                            }
                        ), 409

                    recinto_row = cur.execute(
                        """
                        SELECT id_recinto, id_zona, votos
                        FROM recinto
                        WHERE id_recinto = %(recinto)s
                        FOR UPDATE;
                        """,
                        {"recinto": recinto},
                    ).fetchone()

                    if recinto_row is None:
                        return jsonify(
                            {
                                "status": "error",
                                "message": "Recinto não encontrado."
                            }
                        ), 404

                    acesso_row = cur.execute(
                        """
                        SELECT 1
                        FROM acesso
                        WHERE bid = %(bilhete)s
                          AND id_zona = %(id_zona)s;
                        """,
                        {
                            "bilhete": bilhete,
                            "id_zona": recinto_row.id_zona
                        },
                    ).fetchone()

                    if acesso_row is None:
                        return jsonify(
                            {
                                "status": "error",
                                "message": "O bilhete não tem acesso à zona deste recinto."
                            }
                        ), 403

                    cur.execute(
                        """
                        UPDATE bilhete
                        SET votou = TRUE
                        WHERE bid = %(bilhete)s;
                        """,
                        {"bilhete": bilhete},
                    )

                    cur.execute(
                        """
                        UPDATE recinto
                        SET votos = votos + 1
                        WHERE id_recinto = %(recinto)s;
                        """,
                        {"recinto": recinto},
                    )

            except Exception as e:
                return jsonify(
                    {
                        "status": "error",
                        "message": "Erro ao registar o voto.",
                        "detail": str(e)
                    }
                ), 500

    return jsonify(
        {
            "status": "success",
            "message": "Voto registado com sucesso.",
            "bilhete": bilhete,
            "recinto": recinto
        }
    ), 200

@app.route("/venda/", methods=("POST",))
def venda_save():
    """
    Cria uma venda com um ou mais bilhetes.
    Popula as tabelas venda, bilhete e acesso.
    O pedido deve vir em JSON.
    """

    data = request.get_json(silent=True)

    if data is None:
        return jsonify(
            {
                "status": "error",
                "message": "O pedido deve conter JSON válido."
            }
        ), 400

    nif_cliente = data.get("nif_cliente")
    bilhetes = data.get("bilhetes")

    if bilhetes is None or not isinstance(bilhetes, list) or len(bilhetes) == 0:
        return jsonify(
            {
                "status": "error",
                "message": "A venda deve conter pelo menos um bilhete."
            }
        ), 400

    bilhetes_processados = []

    for i, bilhete in enumerate(bilhetes):
        zonas = bilhete.get("zonas")
        desconto = bilhete.get("desconto", 0)

        if zonas is None or not isinstance(zonas, list) or len(zonas) == 0:
            return jsonify(
                {
                    "status": "error",
                    "message": f"O bilhete {i + 1} deve conter pelo menos uma zona."
                }
            ), 400

        try:
            zonas = [int(z) for z in zonas]
            zonas = list(dict.fromkeys(zonas))
        except Exception:
            return jsonify(
                {
                    "status": "error",
                    "message": f"As zonas do bilhete {i + 1} devem ser números inteiros."
                }
            ), 400

        try:
            desconto = float(desconto)
        except Exception:
            return jsonify(
                {
                    "status": "error",
                    "message": f"O desconto do bilhete {i + 1} deve ser numérico."
                }
            ), 400

        if desconto < 0 or desconto > 1:
            return jsonify(
                {
                    "status": "error",
                    "message": f"O desconto do bilhete {i + 1} deve estar entre 0 e 1."
                }
            ), 400

        bilhetes_processados.append(
            {
                "zonas": zonas,
                "desconto": desconto
            }
        )

    with pool.connection() as conn:
        with conn.cursor() as cur:
            try:
                with conn.transaction():

                    cur.execute("SET CONSTRAINTS ALL DEFERRED;")

                    zonas_todas = []

                    for bilhete in bilhetes_processados:
                        zonas_todas.extend(bilhete["zonas"])

                    zonas_todas = list(dict.fromkeys(zonas_todas))

                    zonas_rows = cur.execute(
                        """
                        SELECT id_zona, preco
                        FROM zona
                        WHERE id_zona = ANY(%(zonas)s);
                        """,
                        {"zonas": zonas_todas},
                    ).fetchall()

                    precos_zonas = {}

                    for row in zonas_rows:
                        precos_zonas[row.id_zona] = decimal_to_float(row.preco)

                    zonas_inexistentes = [
                        z for z in zonas_todas
                        if z not in precos_zonas
                    ]

                    if len(zonas_inexistentes) > 0:
                        raise ValueError(
                            "Existem zonas inexistentes: "
                            + ", ".join(str(z) for z in zonas_inexistentes)
                        )

                    venda_row = cur.execute(
                        """
                        INSERT INTO venda (data_hora, nif_cliente)
                        VALUES (NOW(), %(nif_cliente)s)
                        RETURNING no_venda;
                        """,
                        {"nif_cliente": nif_cliente},
                    ).fetchone()

                    no_venda = venda_row.no_venda

                    resposta_bilhetes = []
                    preco_total = 0

                    for bilhete in bilhetes_processados:
                        zonas = bilhete["zonas"]
                        desconto = bilhete["desconto"]

                        preco_sem_desconto = sum(precos_zonas[z] for z in zonas)
                        preco_bilhete = preco_sem_desconto * (1 - desconto)

                        bilhete_row = cur.execute(
                            """
                            INSERT INTO bilhete (desconto, votou, no_venda)
                            VALUES (%(desconto)s, FALSE, %(no_venda)s)
                            RETURNING bid;
                            """,
                            {
                                "desconto": desconto,
                                "no_venda": no_venda
                            },
                        ).fetchone()

                        bid = bilhete_row.bid

                        for id_zona in zonas:
                            cur.execute(
                                """
                                INSERT INTO acesso (bid, id_zona)
                                VALUES (%(bid)s, %(id_zona)s);
                                """,
                                {
                                    "bid": bid,
                                    "id_zona": id_zona
                                },
                            )

                        resposta_bilhetes.append(
                            {
                                "bid": bid,
                                "zonas": zonas,
                                "desconto": desconto,
                                "preco": round(preco_bilhete, 2)
                            }
                        )

                        preco_total += preco_bilhete

            except ValueError as e:
                return jsonify(
                    {
                        "status": "error",
                        "message": str(e)
                    }
                ), 404

            except Exception as e:
                return jsonify(
                    {
                        "status": "error",
                        "message": "Erro ao criar venda.",
                        "detail": str(e)
                    }
                ), 500

    return jsonify(
        {
            "status": "success",
            "message": "Venda criada com sucesso.",
            "no_venda": no_venda,
            "preco_total": round(preco_total, 2),
            "bilhetes": resposta_bilhetes
        }
    ), 201

if __name__ == "__main__":
    app.run()