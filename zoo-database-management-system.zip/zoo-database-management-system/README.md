# Zoo Database Management System

Academic database project developed for the Databases course at Instituto Superior Técnico.

The project models and implements a zoo information system covering ticket sales, access to zoo zones, animals and species, enclosure popularity voting, and analytical reporting.

## Technologies
- PostgreSQL
- SQL / PL/pgSQL
- Python
- Flask
- psycopg
- Docker

## Main Features
- Relational database schema for zones, enclosures, species, animals, sales and tickets
- Integrity constraints and database triggers
- Ticket sales and zone-access management
- Voting system for zoo enclosures
- Flask REST API connected to PostgreSQL
- Materialized views and analytical SQL queries
- OLAP operations using `GROUPING SETS` and `CUBE`
- Index creation and performance analysis with `EXPLAIN ANALYZE`

## Structure
- `app/` — Flask API and Docker configuration
- `database/zoo-database-project.ipynb` — database schema, constraints, data analysis and indexing work

## Notes
This was a group academic project. The Flask application uses course-provided starter infrastructure which was extended with the project-specific database and API functionality.
